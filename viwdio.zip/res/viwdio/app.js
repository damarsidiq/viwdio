var appname = 'viwdio';
var listofvid = [];
var searchres = [];

var viewmode = 'start';
var savedsearchres = [];
var savedsearchresq = [];
var savedsearchresidx = false;
var player=false;
var playerready=false;
var avideoplaying=false;
var videoplayingid=false;
var videoplayingtitle=false;
var beforerelatedidx=false;
var playerhasfocus=false;
var justexitfs=false;

var apikey = 'AIzaSyDxM_le0Ul0_Jl_1VrZRatOL8Bg6iQo-FA';

var focusedvid = false;
var downloadstats=[];
var queue=[];
var queuetitle=[];
var cqueue=-1;

function navvilist(direct){
    if(viewmode !== 'vilist')
        return;
        
    if(direct == 13){
        if(focusedvid === false){
            return;
        }
        
       if($('#viwdio').attr('class').indexOf('activemin') === -1){
            $('.maincontent').removeClass('active loading');
            $('#opaque').addClass('active loading');                
        }
        switch($('.sr.focus').attr('id').split('_')[0]){
            case 'videoid':
                if(playerready){
                    var theid = $('.sr.focus').attr('id').split('videoid_')[1];
                    if(queue.length){
                        var tcqueue = $.inArray(theid,queue);
                        if(tcqueue !== -1){
                            cqueue = tcqueue;
                            videoplayingid = queue[cqueue];
                            videoplayingtitle = queuetitle[cqueue];
                            player.loadVideoById(queue[cqueue],0,"large");
                            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                        }
                        else{
                            queue[queue.length] = theid;
                            queuetitle[queuetitle.length] = $('.sr.focus').parent().prev().html();
                            cqueue = queue.length-1;
                            
                            videoplayingid = queue[cqueue];
                            videoplayingtitle = queuetitle[cqueue];
                            player.loadVideoById(queue[cqueue],0,"large");
                            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                        }
                    }
                    else{
                        loadavideo(theid,$('.sr.focus').parent().prev().html());   
                    }
                }       
            break;
            case 'channelid':
                loadachannel($('.sr.focus').attr('id').split('channelid_')[1]);
            break;
            case 'playlistid':
                loadaplaylist($('.sr.focus').attr('id').split('playlistid_')[1]);
            break;
        }
        return;
    }
    if(direct == 40){
        if(focusedvid === false){
            $('#vilist').children().eq(0).addClass('focus');
            focusedvid = $('.sr.focus');
            $(focusedvid)[0].scrollIntoView();
            return;
        }
        
        if(typeof $(focusedvid).next().attr('class') === 'undefined'){
            $('#vilist').children().eq(0).addClass('focus');
            focusedvid = $('.sr.focus');
            $(focusedvid)[0].scrollIntoView();
            return;
        }
        
        
        focusedvid = $('.sr.focus').next();
        $('.sr.focus').removeClass('focus');
        $(focusedvid).addClass('focus');
        
        $(focusedvid)[0].scrollIntoView();
        
        return;
    }
    if(focusedvid === false){
        $('#vilist').children().eq(14).addClass('focus');
        focusedvid = $('.sr.focus');
        $(focusedvid)[0].scrollIntoView();
        return;
    }
    if(typeof $(focusedvid).prev().attr('class') === 'undefined'){
        $('#vilist').children().eq(14).addClass('focus');
        focusedvid = $('.sr.focus');
        $(focusedvid)[0].scrollIntoView();
        return;
    }
    
    focusedvid = $('.sr.focus').prev();
    $('.sr.focus').removeClass('focus');
    $(focusedvid).addClass('focus');
    
    $(focusedvid)[0].scrollIntoView();
}
function itemdownloads(){
    var boxcontent = '';
    if(downloadstats.length){
        boxcontent+='<ul id="downloaditemsstats">';
        var dstats = '';
        var dstatcent = '';
        for(var i=0;i<downloadstats.length;i++){
            if(downloadstats[i].status.toString().indexOf('cancelled') === -1){
                if(downloadstats[i].status.toString().indexOf('paused') !== -1){
                    dstats = '<span>X</span><span>&gt;</span>';
                    dstatcent = ((downloadstats[i].status/downloadstats[i].tosize) *100).toFixed(2) +'%';
                }
                else if(downloadstats[i].status.toString().indexOf('done') !== -1){
                    dstatcent = '100%';
                    dstats = '<span>X</span>';
                }
                else if(downloadstats[i].status.toString().indexOf('failed') !== -1){
                    dstatcent = 'failed';
                    dstats = '<span>X</span><span>&gt;</span>';
                }
                else{
                    dstatcent = ((downloadstats[i].status/downloadstats[i].tosize) *100).toFixed(2) +'%';
                    dstats = '<span>X</span><span>||</span>';
                }
                boxcontent+='<li id="doit_'+i+'"><span class="itemdownloadsaction">'+dstats+'</span><span class="itemstatus">'+dstatcent+'</span><span class="itemname">'+(i+1)+'.'+downloadstats[i].name+'</span></li>';
            }
        }
        boxcontent+='</ul>';
    }
    else{
        boxcontent+='no downloads found';
    }
    $('#downloadpage').html('<span class="close">X</span>'+boxcontent);
}
function downloadnews(bytereceiv){
    var bytereceivx = bytereceiv.split('<edsep>');
    var didx;
    if(bytereceiv.indexOf('downdone<edsep>')!==-1){
        for(var i=0;i<downloadstats.length;i++){
            if(downloadstats[i].url == bytereceivx[2]){
                didx = i;
                break;
            }
        }
        downloadstats[didx].status = 'done';
    }
    else if(bytereceiv.indexOf('startdownload<edsep>')!==-1){
        downloadstats[downloadstats.length] = [];
        didx =downloadstats.length-1;
        downloadstats[didx].status = 0;
        downloadstats[didx].name = bytereceivx[0];
        downloadstats[didx].url = bytereceivx[3];
        downloadstats[didx].tosize = parseInt(bytereceivx[1]);
        
        updatemenu('downloads','downloads','add');
        
        $('#downloadfromyt').removeClass('active');
        $('body').children('.close').remove();
        itemdownloads();
        $('#downloadpage').addClass('active');
    }
    else if(bytereceiv.indexOf('downfailed<edsep>')!==-1){
        for(var i=0;i<downloadstats.length;i++){
            if(downloadstats[i].url == bytereceivx[3]){
                didx = i;
                break;
            }
        }
        if(downloadstats[didx].status.toString().indexOf('cancelled') ===-1)
            downloadstats[didx].status = 'failed:'+bytereceivx[2];
    }
    else{
        for(var i=0;i<downloadstats.length;i++){
            if(downloadstats[i].url == bytereceivx[2]){
                didx = i;
                break;
            }
        }
        downloadstats[didx].status = parseInt(bytereceivx[1]);
        
        if(typeof $('#downloadpage').attr('class') !== 'undefined' && $('#downloadpage').attr('class').indexOf('active') !== -1)
            $('#doit_'+didx).children('.itemstatus').html(((downloadstats[didx].status/downloadstats[didx].tosize) *100).toFixed(2) +'%');
    }
}

document.onwebkitfullscreenchange = function( event ) {
    if(playerhasfocus){
        playerhasfocus = false;
        justexitfs=true;
        $('#player').contents().find('video').blur();
        $('#player').blur();
        $('body').focus();
        
        updatenav('playvideo');
        return;
    }
    else{
        playerhasfocus = true;
    }
};

function createwebview(url){
    if($('#downloadfromyt').length){
        $('#downloadfromyt').remove();
    }
    $('#opaque').addClass('active loading small');
    $('body').append('<webview id="downloadfromyt" class="maincontent active" src="'+url+'" plugins allowpopups disablewebsecurity webpreferences="allowRunningInsecureContent"></webview>');
    $('#downloadfromyt').before('<div class="close">X</div>');
    
    
    document.getElementById('downloadfromyt').addEventListener('load-commit', function(){
        $('#opaque').removeClass('loading');
    });
    document.getElementById('downloadfromyt').addEventListener('dom-ready', function(){
        $('#opaque').removeClass('active small');
    });
}
$(document).ready(
    function(){
        loadyoutubeiframeapi();
        getLocalStorage();
        
        $('body').on('keyup',function(event){
            event.stopPropagation();
            if(viewmode == 'search'){
                if(event.which == 27){
                    if(justexitfs){
                        justexitfs=false;
                        return;
                    }
                    updatenav('vilist');
                }
                return;
            }
            
            switch(event.which){
                case 13:
                    navvilist(13);
                break;
                case 40:
                    navvilist(40);
                break;
                case 38:
                    navvilist(38);
                break;
                case 39:
                    if(viewmode =='vilist'){
                        navtonext();
                    }
                    else if(viewmode=='playvideo'){
                        if(!queue.length){
                            return;
                        }
                        
                        cqueue++;
                        cqueue = cqueue == queue.length ? 0 : cqueue;
                        videoplayingid = queue[cqueue];
                        player.loadVideoById(queue[cqueue],0,"large");
                        $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                    }
                break;
                case 37:
                    if(viewmode =='vilist'){
                        navtoprev();
                    }
                    else if(viewmode=='playvideo'){
                        if(!queue.length){
                            return;
                        }
                        
                        cqueue--;
                        cqueue = cqueue == -1 ? (queue.length-1) : cqueue;
                        videoplayingid = queue[cqueue];
                        player.loadVideoById(queue[cqueue],0,"large");
                        $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                    }
                break;
                case 81:
                    if(avideoplaying){
                        stopVideo();
                        avideoplaying = false;
                        updatenav('vilist');
                        updatemenu('downloadvidensave','','remove');
                    } 
                break;
                case 76:
                    if(avideoplaying){
                       if(viewmode == 'playvideo'){
                           showrelated();
                       }
                    }
                break;
                case 27:
                    updatenav('vilist');
                break;
                case 86:
                    if(avideoplaying){
                        if(!playerhasfocus){
                            updatenav('playvideo');
                            $('#player').contents().find('video').focus(); 
                            thisVid = document.getElementById("player");

                            if (thisVid.requestFullscreen) {
                                thisVid.requestFullscreen();
                            }
                            else if (thisVid.msRequestFullscreen) {
                                thisVid.msRequestFullscreen();
                            }
                            else if (thisVid.mozRequestFullScreen) {
                                thisVid.mozRequestFullScreen();
                            }
                            else if (thisVid.webkitRequestFullScreen) {
                                thisVid.webkitRequestFullScreen();
                            }
                        }
                    }
                break;
                case 70:
                    if(avideoplaying){
                        if(viewmode =='vilist')
                            updatenav('playvideo');
                        else if(viewmode == 'playvideo'){
                            updatenav('vilist');
                        }
                    }
                break;
                case 82:
                    menuitemaction('searchyou');
                break;
                case 83:
                    menuitemaction('downloadvidensave');
                break;
            }
        });
        
        $('#nav').on('click',function(event){
            event.stopPropagation();
            
            $('#menulist').removeClass('active');
        });
        $('#pagenav').on('click',function(event){
            event.stopPropagation();
            
            $('#menulist').removeClass('active');
        });
        
        $('body').delegate('.itemlinks span','click',function(event){
            event.stopPropagation();
            
            switch($(this).attr('class')){
                case 'downloadfromensavefromdotnet first':
                    $('#opaque').addClass('active small loading');
                    createwebview('http://www.ssyoutube.com/watch?v='+$(this).parent().parent().attr('id').split('videoid_')[1]);
                break;
                case 'playlistqueue':
                    updatemenu('resetqueue','clear playlist','add');
                    if($(this).attr('class').indexOf('queued') !== -1){
                        return;
                    }
                    $(this).addClass('queued');
                    queuetitle[queuetitle.length] = $(this).parent().prev().html();
                    queue[queue.length] = $(this).parent().parent().attr('id').split('videoid_')[1];
                    if(queue.length == 1){
                        cqueue = 0;
                        if(avideoplaying){
                            queue.unshift(videoplayingid);
                            queuetitle.unshift(videoplayingtitle);
                        }
                        else{
                            loadavideo(queue[cqueue],queuetitle[cqueue]);   
                        }
                    }
                    $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                    savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].cpage] = $('#vilist').html();
                break;
            }
        });
      
        $('#searchq').on('keypress',function(event){
            event.stopPropagation();
            if($(this).val() == 'keyword'){
                $(this).val('');
            }
            if(event.which == 13){
                $('.searcheditems').removeClass('hide');
                searchres.q = $(this).val();
                if(searchres.q != '' && searchres.q != 'keyword')
                    searchyoutube();
                    
                return;
            }
            else if(event.which == 126){  
                event.preventDefault();
                
                var c = $('.searcheditems.selecting');
                $('.searcheditems.selecting').removeClass('selecting');
                var cus = $('.searcheditems.show');
                var cusi=0;
                for(var i=0;i<cus.length;i++){
                    if($(cus).eq(i).html() == $(c).html()){
                        cusi = i+1;
                        break;
                    }
                }
                if(cusi == cus.length){
                    cusi = 0;
                }
                $(cus).eq(cusi).addClass('selecting');
                $(cus).eq(cusi)[0].scrollIntoView();
                return;
            }
            else if(event.which == 27){
                $('.searcheditems').removeClass('hide');
                updatenav('vilist');
            }
        });
        $('#searchq').on('keyup',function(event){
            event.stopPropagation();
            
            if($(this).val() == ''){
                $('.searcheditems').removeClass('hide selecting');
                $(this).val('keyword');
            }
            else if($(this).val() == 'keyword'){
                $('.searcheditems').removeClass('hide selecting');
            }
            else{
                if(event.which == 192 || event.which == 16){
                    if(event.which == 16){
                        if(typeof $('.searcheditems.selecting').attr('class') === 'undefined')
                            return;
                            
                        $('#searchq').val($('.searcheditems.selecting').html().split('<a ')[0]);
                        $('.searcheditems').removeClass('hide');
                        searchres.q = $(this).val();
                        searchyoutube();
                    }
                    return;
                }
                else{
                    var searval = $('#searchq').val();
                    $('.searcheditems').addClass('hide').removeClass('show');
                    $('.searcheditems.selecting').removeClass('selecting');
                    var selecting = false;
                    $.each($('.searcheditems'),function(si,su){
                        if($(su).html().split('<a ')[0].indexOf(searval) !== -1){
                            selecting = selecting === false ? $(su) : selecting;
                            $(su).removeClass('hide').addClass('show');
                        }
                    });
                    if(selecting !== false){
                        $(selecting).addClass('selecting');
                        $(selecting)[0].scrollIntoView();
                    }    
                }
            }
        });
        $('#searchq').on('blur',function(event){
            if($(this).val() == ''){
                $('.searcheditems').removeClass('hide');
                $(this).val('keyword');
            }
        });
        $('#menu').on('click',function(event){
            event.stopPropagation();
            
            if($('#menulist').attr('class').indexOf('active') === -1)
                $('#menulist').addClass('active');
            else
                $('#menulist').removeClass('active');
        });
        
        $('#menu').delegate('.menuitem','click',function(event){
            event.stopPropagation();
            
            menuitemaction(this.id);
        });
        $('#whatsinqueue').on('click',function(event){
            event.stopPropagation();
            toggleplaylistpage();
        });
        $('#playlistpage').delegate('div','click',function(event){
            event.stopPropagation();
            
            cqueue = parseInt($(this).attr('id').split('_')[1]);
            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
            videoplayingid = queue[cqueue];
            videoplayingtitle = queuetitle[cqueue];
            player.loadVideoById(queue[cqueue],0,"large");
        }); 
        $('#playlistpage').delegate('span','click',function(event){
            event.stopPropagation();
            
            var qid = parseInt($(this).parent().attr('id').split('_')[1]);
            for(var i=0;i<savedsearchres.length;i++){
                for(var ii=0;ii<savedsearchres[i].pages.length;ii++){
                    if(savedsearchres[i].pages[ii].indexOf('videoid_'+queue[qid]) !== -1){
                        var a = savedsearchres[i].pages[ii].split('videoid_'+queue[qid]);
                        for(var ai=0;ai<a.length;ai++){
                            if(ai % 2 != 0){
                                var b = a[ai].split('playlistqueue queued');
                                a[ai] = b[0]+'playlistqueue'+b[1];
                                b.splice(0,1);
                                b.splice(0,1);
                                if(b.length){
                                    a[ai]+= 'playlistqueue queued'+b.join('playlistqueue queued');   
                                }
                            }
                        }
                        savedsearchres[i].pages[ii] = a.join('videoid_'+qid);
                    }
                }
            }
            $('#vilist').html(savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].cpage]);
            
            queue.splice(qid,1);
            queuetitle.splice(qid,1);
            if(qid == cqueue){
                cqueue-=1;
                if(cqueue<0){
                    cqueue=0;
                }                
                videoplayingid = queue[cqueue];
                videoplayingtitle = queuetitle[cqueue];
                player.loadVideoById(queue[cqueue],0,"large");
                $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
            }
            else if(cqueue > qid){
                cqueue-=1;
                if(cqueue<0){
                    cqueue=0;
                }
            }
            
            if(!queue.length){
                stopVideo();
                avideoplaying = false;
                updatenav('vilist');
                updatemenu('downloadvidensave','','remove');
            }
            else{
                var ppc = '';
                for(var i=0;i<queue.length;i++){
                    ppc+= '<div id="ppc_'+i+'">'+(i+1)+'. '+queuetitle[i]+'<span>X</span></div>';
                }
                $('#playlistpage').html(ppc);
                $('#playlistpage').addClass('active');
                
                $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
            }
        });
        $('body').delegate('.sr','click',function(event){
            event.stopPropagation();
            
            if($('#viwdio').attr('class').indexOf('activemin') === -1){
                $('.maincontent').removeClass('active loading');
                $('#opaque').addClass('active loading');                
            }
            switch($(this).attr('id').split('_')[0]){
                case 'videoid':
                    var theid = $(this).attr('id').split('videoid_')[1];
                    if(playerready){
                        if(queue.length){
                            var tcqueue = $.inArray(theid,queue);
                            if(tcqueue !== -1){
                                cqueue = tcqueue;
                                videoplayingid = queue[cqueue];
                                videoplayingtitle = queuetitle[cqueue];
                                player.loadVideoById(queue[cqueue],0,"large");
                                $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                            }
                            else{
                                queue[queue.length] = theid;
                                queuetitle[queuetitle.length] = $(this).children('.srtitle').html();
                                cqueue = queue.length-1;
                                
                                videoplayingid = queue[cqueue];
                                videoplayingtitle = queuetitle[cqueue];
                                player.loadVideoById(queue[cqueue],0,"large");
                                $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
                            }
                        }
                        else{
                            loadavideo(theid,$(this).children('.srtitle').html());   
                        }
                    }       
                break;
                case 'channelid':
                    loadachannel($(this).attr('id').split('channelid_')[1]);
                break;
                case 'playlistid':
                    loadaplaylist($(this).attr('id').split('playlistid_')[1]);
                break;
            }
        });
        
        $('#navtonext').on('click',function(event){
            event.stopPropagation();
            
            navtonext();
        });
        $('#navtoprev').on('click',function(event){
            event.stopPropagation();
            
            navtoprev();
        });
        $('body').delegate('.searcheditems a','click',function(event){
            event.stopPropagation();
            userdata.remsearched($(this).parent()[0].innerText);
            $(this).parent().remove();
        });
        $('body').delegate('.searcheditems','click',function(event){
            event.stopPropagation();
            
            searchres.q = $(this).html().split('<a href')[0];
            if(searchres.q != '' && searchres.q != 'keyword')
                searchyoutube();
        });
        
        $('#showvideo').on('click',function(event){
            event.stopPropagation();
            
            if(avideoplaying){
                updatenav('playvideo');
            }
        });
        
        $('body').delegate('.close','click',function(event){
            event.stopPropagation();
            if(typeof $(this).parent().attr('id') === 'undefined'){
                resetwebview();
                $(this).remove();
            }
            
            switch($(this).parent().attr('id')){
                case 'relviwdio':
                    updatenav('playvideo');
                break;
                case 'downloadpage':
                    $('#downloadpage').removeClass('active');
                break;
                default:
                    $(this).parent().removeClass('active');
            }
        });
        
        
        $('#relatedvideo').on('click',function(event){
            event.stopPropagation();
            showrelated();
        });
        
        $('#nextinqueue').on('click',function(event){
            event.stopPropagation();
            
            cqueue++;
            cqueue = cqueue == queue.length ? 0 : cqueue;
            videoplayingid = queue[cqueue];
            videoplayingtitle = queuetitle[cqueue];
            player.loadVideoById(queue[cqueue],0,"large");
            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
        });
        
        $('#previnqueue').on('click',function(event){
            event.stopPropagation();
            
            cqueue--;
            cqueue = cqueue == -1 ? (queue.length-1) : cqueue;
            videoplayingid = queue[cqueue];
            videoplayingtitle = queuetitle[cqueue];
            player.loadVideoById(queue[cqueue],0,"large");
            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
        });
        
        $('#removevideo').on('click',function(event){
            event.stopPropagation();
            
            if(avideoplaying){
                stopVideo();
                avideoplaying = false;
                updatenav('vilist');
                updatemenu('downloadvidensave','','remove');
            }
        });
        
        updatenav('search');
        if(isanelectronapp){
            ipcRenderer.on('asynchronous-reply', (event, arg) => {
                var didx;
                switch(arg.split('<edsep>')[0]){
                    case 'pausedownload':
                        for(var i=0;i<downloadstats.length;i++){
                            if(downloadstats[i].url == arg.split('<edsep>')[1]){
                                downloadstats[i].status = downloadstats[i].status+'<edsep>paused';
                                didx = i;
                                break;
                            }
                        }
                        $('#doit_'+didx).children('.itemdownloadsaction').children().eq(1).html('&gt;');
                    break;
                    case 'resumedownload':
                        for(var i=0;i<downloadstats.length;i++){
                            if(downloadstats[i].url == arg.split('<edsep>')[1]){
                                if(downloadstats[i].status.toString().indexOf('<edsep>paused') !== -1){
                                    downloadstats[i].status = parseInt(downloadstats[i].status.split('<edsep>')[0]);
                                }
                                didx=1;
                                break;
                            }
                        }
                        $('#doit_'+didx).children('.itemdownloadsaction').children().eq(1).html('||');
                    break;
                    case 'canceldownload':
                        for(var i=0;i<downloadstats.length;i++){
                            if(downloadstats[i].url == arg.split('<edsep>')[1]){
                                didx=i;
                                break;
                            }
                        }
                        $('#doit_'+didx).remove();
                        
                        if(!$('#downloaditemsstats').children().length){
                            $('#downloaditemsstats').replaceWith('<div class="table"><div class="tablecell" style="text-align:center;">no downloads found</div></div>');
                        }
                        downloadstats[didx].status = downloadstats[didx].status+'<edsep>cancelled';
                    break;
                }
            });
            $('#downloadpage').delegate('.itemdownloadsaction span','click',function(){
                if($(this).html() == '||'){
                    ipcRenderer.send('asynchronous-message', 'pausedownload<edsep>'+downloadstats[parseInt($(this).parent().parent().attr('id').split('_')[1])].url);
                    return;
                }
                else if($(this).html() == '&gt;'){
                    ipcRenderer.send('asynchronous-message', 'resumedownload<edsep>'+downloadstats[parseInt($(this).parent().parent().attr('id').split('_')[1])].url);
                    return;
                }
                
                ipcRenderer.send('asynchronous-message', 'canceldownload<edsep>'+downloadstats[parseInt($(this).parent().parent().attr('id').split('_')[1])].url);
            });   
        }
    }
);

function toggleplaylistpage(){
    if($('#playlistpage').attr('class').indexOf('active') === -1){
        var ppc = '';
        for(var i=0;i<queue.length;i++){
            ppc+= '<div id="ppc_'+i+'">'+(i+1)+'. '+queuetitle[i]+'<span>X</span></div>';
        }
        $('#playlistpage').html(ppc);
        $('#playlistpage').addClass('active');
    }
    else{
        $('#playlistpage').removeClass('active');
    }
}

function showrelated(){
    $('.maincontent').removeClass('active');
    $('#opaque').addClass('active loading');
    
    searchres.q = videoplayingid+'#related';
    
    if(savedsearchres.length){
        for(var i=0;i<savedsearchres.length;i++){
            if(savedsearchres[i].searchres.q == searchres.q){
                beforerelatedidx = savedsearchresidx;
                savedsearchresidx = i;
                dispsearchresults('relviwdio');
                return;
            }
        }
    }
    
    beforerelatedidx = savedsearchresidx;
    var url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&relatedToVideoId='+videoplayingid+'&type=video&fields=items%2CnextPageToken%2CpageInfo&key='+apikey;
    $('#relviwdio').html('');
    sendapireq(url,true,'relviwdio',searchres.q);
}
function menuitemaction(menuid){
    switch(menuid){
        case 'resetqueue':
            queue = [];
            queuetitle=[];
            cqueue = -1;
            $('.queuenav').removeClass('active');
            $('#resetqueue').remove();
        break;
        case 'exit':
             ipcRenderer.send('asynchronous-message', 'quitbro<edsep>');
        break;
        case 'downloads':
            $('#menulist').removeClass('active');
            itemdownloads();
            $('#downloadpage').addClass('active');
        break;
        case 'searchyou':
            $('#menulist').removeClass('active');
            
            updatenav('search');
            
            $('#searchq').focus();
        break;
        case 'downloadvidensave':
            if(!avideoplaying)
                return;
            
            $('#menulist').removeClass('active');
            createwebview('http://www.ssyoutube.com/watch?v='+videoplayingid);
        break;
    }
}
function resetwebview(){
    $('#downloadfromyt').remove();
    $('#opaque').removeClass('active loading small');
}
function navtonext(){
    switch(viewmode){
        case 'playvideo':
        break;
        case 'vilist':
            nextsearchpage();
        break;
    }
}
function navtoprev(){
    switch(viewmode){
        case 'relviwdio':
        case 'playvideo':
        case 'search':
            updatenav('vilist');
        break;
        case 'vilist':
            prevsearchpage();
        break;
    }
}
function updatemenu(menuid,menuname,mode){
    if(mode = 'add' && typeof $('#'+menuid).attr('class') === 'undefined'){
        $('#menulist').children('#exit').before('<li class="menuitem" id="'+menuid+'">'+menuname+'</li>');
    }
    else if(mode == 'remove' && typeof $('#'+menuid).attr('class') !== 'undefined'){
        $('#'+menuid).remove();
    }
}
function updatenav(activity){
    switch(activity){
        case 'start':
            $('.maincontent').removeClass('active loading');
            $('#pagenav').addClass('active').children().removeClass('active');
        break;
        case 'playvideo':
            $('.maincontent').removeClass('active loading');
            $('#viwdio').removeClass('activemin').addClass('active');
            $('#pagenav').addClass('active').children().removeClass('active');
            
            $('#navtoprev').addClass('active');
            $('#removevideo').addClass('active');
            if(queue.length){
                $('.queuenav').addClass('active');    
            }
            
            $('#relatedvideo').addClass('active');
            
            if(beforerelatedidx !== savedsearchresidx && beforerelatedidx !== false){
                savedsearchresidx = beforerelatedidx;
                beforerelatedidx = false;
            }
        break;
        case 'search':
            $('.maincontent').removeClass('active loading');
            $('#searchform').addClass('active');
            $('#searchedkeys').addClass('active');
            $('#opaque').addClass('active');
            
            $('#pagenav').addClass('active').children().removeClass('active');
            $('#navtoprev').addClass('active');
            
            $('#searchq').focus();
            
            if(avideoplaying || queue.length){
                $('#viwdio').addClass('activemin');
                $('#showvideo').addClass('active');   
            }
        break;
        case 'relviwdio':
            $('.maincontent').removeClass('active loading');
             $('#relviwdio').addClass('active');
             $('#viwdio').addClass('active');
             
            $('#pagenav').addClass('active').children().removeClass('active');
            
            $('#navtoprev').addClass('active');
            $('#removevideo').addClass('active');
            if(queue.length){
                $('.queuenav').addClass('active');    
            }
        break;
        case 'vilist':
            if(savedsearchresidx===false){
                activity = 'start';
                updatenav(activity);
                return;
            }
            if(beforerelatedidx !== savedsearchresidx && beforerelatedidx !== false){
                savedsearchresidx = beforerelatedidx;
                beforerelatedidx = false;
            }
            $('.maincontent').removeClass('active loading');
            $('#vilist').addClass('active');
            $('#pagenav').addClass('active').children().removeClass('active');
            
            $('#navtonext').addClass('active');
            
            if(savedsearchres[savedsearchresidx].cpage > 0){
                $('#navtoprev').addClass('active');
            }
            
            $('#pagecount').addClass('active');
            
            if(avideoplaying || queue.length){
                $('#viwdio').addClass('activemin');
                $('#showvideo').addClass('active');   
            }
        break;
    }
    viewmode = activity;
}
function searchstr(){
    var str = searchres.q;
    return str;
}
function sendapireq(url,newsearch,containerid,searchq){
    $.ajax({
        url:url,
        type:'GET'
    }).done(function(msg){
        msg = JSON.stringify(msg);
        msg = JSON.parse(msg);
        
        var resu = msg;
        
        $.each(resu.items,function(mi,me){
            if(typeof me.id.kind === 'undefined'){
                playlistitemsr(me.snippet,containerid);
            }
            else{
                switch(me.id.kind){
                    case 'youtube#channel':
                        channelsr(me.id,me.snippet,containerid);
                    break;
                    case 'youtube#video':
                        videosr(me.id,me.snippet,containerid);
                    break;
                    case 'youtube#playlist':
                        playlistsr(me.id,me.snippet,containerid);
                    break;
                }   
            }
        });
        
        resu.q = searchq;
        
        if(newsearch){
            savedsearchresidx = savedsearchres.length;
            
            savedsearchresq[savedsearchresidx] = searchq;
            
            savedsearchres[savedsearchresidx] = [];
            savedsearchres[savedsearchresidx].searchres = resu;
            savedsearchres[savedsearchresidx].pages = [];            
            savedsearchres[savedsearchresidx].cpage = 0;
            savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].pages.length] = $('#'+containerid).html();
        }
        else{
            savedsearchres[savedsearchresidx].searchres = resu;
            savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].pages.length] = $('#'+containerid).html();    
            savedsearchres[savedsearchresidx].cpage = savedsearchres[savedsearchresidx].pages.length-1;
        }
        updatenav(containerid);
        
        if(containerid == 'vilist'){
            $('#pagecount').html((savedsearchres[savedsearchresidx].cpage+1));
            $('#vilist').scrollTop(0);            
        }
        else if(containerid == 'relviwdio'){
            $('#relviwdio').children().eq(0).before('<div class="close">X</div>');
        }
    });
}
function dispsearchresults(containerid){
    $('#'+containerid).html(savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].cpage]);
    updatenav(containerid);
    
    if(containerid == 'vilist')
        $('#pagecount').html((savedsearchres[savedsearchresidx].cpage+1));
    else if(containerid == 'relviwdio'){
        $('#relviwdio').children().eq(0).before('<div class="close">X</div>');
    }
}
function searchyoutube(){
    $('.maincontent').removeClass('active');
    $('#opaque').addClass('active loading');
    
    if(savedsearchres.length){
        for(var i=0;i<savedsearchres.length;i++){
            if(savedsearchres[i].searchres.q == searchres.q){
                savedsearchresidx = i;
                dispsearchresults('vilist');
                return;
            }
        }
    }
    if($.inArray(searchres.q,userdata.searchedkeys) === -1){
        userdata.newsearch(searchres.q);
    }
    var url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&q='+searchres.q+'&type=video%2Cchannel%2Cplaylist&fields=items%2CnextPageToken%2CpageInfo&key='+apikey;
    $('#vilist').html('');
    sendapireq(url,true,'vilist',searchres.q);
}
function prevsearchpage(){
    if(savedsearchres[savedsearchresidx].cpage ==0)
        return;
        
    savedsearchres[savedsearchresidx].cpage--;
    $('#vilist').html('');
    $('#vilist').html(savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].cpage]);
    
    updatenav('vilist');
    
    $('#pagecount').html((savedsearchres[savedsearchresidx].cpage+1));
}
function nextsearchpage(){
    $('.maincontent').removeClass('active');
    $('#opaque').addClass('active loading');
    
    if(savedsearchres[savedsearchresidx].cpage == savedsearchres[savedsearchresidx].pages.length-1){
        var url;
        if(savedsearchresq[savedsearchresidx].indexOf('#playlistitems') !== -1){
            if(typeof savedsearchres[savedsearchresidx].searchres.nextPageToken === 'undefined'){
                updatenav('vilist');
                return;
            }
            url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=15&pageToken='+savedsearchres[savedsearchresidx].searchres.nextPageToken+'&playlistId='+savedsearchres[savedsearchresidx].searchres.q.split('#playlistitems')[0]+'&key='+apikey;
            
        }
        else if(savedsearchresq[savedsearchresidx].indexOf('#related') !== -1){
            if(typeof savedsearchres[savedsearchresidx].searchres.nextPageToken === 'undefined'){
                updatenav('vilist');
                return;
            }
            url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&relatedToVideoId='+savedsearchres[savedsearchresidx].searchres.q.split('#related')[0]+'&type=video&fields=items%2CnextPageToken%2CpageInfo&key='+apikey;
        }
        else{
            url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&pageToken='+savedsearchres[savedsearchresidx].searchres.nextPageToken+'&maxResults=15&q='+savedsearchres[savedsearchresidx].searchres.q+'&type=video&fields=items%2CnextPageToken%2CpageInfo&key='+apikey;   
        }
        $('#vilist').html('');
        sendapireq(url,false,'vilist',savedsearchresq[savedsearchresidx]);        
    }
    else{
        savedsearchres[savedsearchresidx].cpage++;
        $('#vilist').html('');
        $('#vilist').html(savedsearchres[savedsearchresidx].pages[savedsearchres[savedsearchresidx].cpage]);
        
        updatenav('vilist');
        $('#pagecount').html((savedsearchres[savedsearchresidx].cpage+1));
        
        $('#vilist').scrollTop(0);
    }
}
function playlistitemsr(snippet,containerid){
    var thumbsrc = '';
    if(typeof snippet.thumbnails === 'undefined'){
        thumbsrc = '';
    }
    else{
        thumbsrc = snippet.thumbnails.medium.url;
    }
        
    $('#'+containerid).append('<div class="sr" id="videoid_'+snippet.resourceId.videoId+'"><img src="'+thumbsrc+'"><div class="srtitle">'+snippet.title+'</div><div class="itemlinks"><span class="downloadfromensavefromdotnet first">en.savefrom.net</span><span class="playlistqueue"></span></div><div class="srdesc">'+snippet.description+'</div></div>');
}
function playlistsr(sid,snippet,containerid){
    var thumbsrc = '';
    if(typeof snippet.thumbnails === 'undefined'){
        thumbsrc = '';
    }
    else{
        thumbsrc = snippet.thumbnails.medium.url;
    }
    
    $('#'+containerid).append('<div class="sr" id="playlistid_'+sid.playlistId+'"><img src="'+thumbsrc+'"><div class="srtitle">'+snippet.title+'</div><div class="srdesc">'+snippet.description+'</div></div>');
}
function videosr(sid,snippet,containerid){
    $('#'+containerid).append('<div class="sr" id="videoid_'+sid.videoId+'"><img src="'+snippet.thumbnails.medium.url+'"><div class="srtitle">'+snippet.title+'</div><div class="itemlinks"><span class="downloadfromensavefromdotnet first">en.savefrom.net</span><span class="playlistqueue"></span></div><div class="srdesc">'+snippet.description+'</div></div>');
}
function channelsr(sid,snippet,containerid){
    var thumbsrc = '';
    if(typeof snippet.thumbnails === 'undefined'){
        thumbsrc = '';
    }
    else{
        thumbsrc = snippet.thumbnails.medium.url;
    }
    
    $('#'+containerid).append('<div class="sr" id="channelid_'+sid.channelId+'"><img src="'+thumbsrc+'"><div class="srtitle">'+snippet.title+'</div><div class="srdesc">'+snippet.description+'</div></div>');
}

var userdata={
    searchedkeys:[],
    searchedkeysstr:'',
    remsearched:function(remstr){
        var torem = remstr.substr(0,remstr.length-1);
        var toremidx = $.inArray(torem,userdata.searchedkeys);
        userdata.searchedkeys.splice(toremidx,1);
        userdata.searchedkeysstr = userdata.searchedkeys.join('<e>');
        localstorage.setItem('searchedkeys',userdata.searchedkeysstr);
    },
    newsearch:function(sq){
        userdata.searchedkeys[userdata.searchedkeys.length] = sq;
        $('#searchedkeys').append('<span class="searcheditems">'+sq+'<a href="javascript:void(0);">x</a></span>');
        userdata.searchedkeysstr = userdata.searchedkeys.join('<e>');
        localstorage.setItem('searchedkeys',userdata.searchedkeysstr);
    },
    init:function(){
        var sk = localstorage.getItem('searchedkeys');
        if(sk === null || sk == 'null' || sk == 'undefined' || sk === ''){
            sk='';
        }
        userdata.searchedkeysstr=sk;
        
        var skx = sk.split('<e>');
        var skhtml = '';
        for(var o=0;o<skx.length;o++){
            if(skx[o]=='')
                continue;
                
            userdata.searchedkeys[o] = skx[o];
            skhtml+='<span class="searcheditems">'+skx[o]+'<a href="javascript:void(0);">x</a></span>';
        }
        
        $('#searchedkeys').html(skhtml);
    },
};

var localstorage = false;
function getLocalStorage(){
    if (typeof localStorage == "object"){
        localstorage =  localStorage;
    } else if (typeof globalStorage == "object"){
        localstorage = globalStorage[location.host];
    } else {
        localstorage = false;
    }
    if(localstorage !== false)
        userdata.init();
}



/*player related fn*/
function loadyoutubeiframeapi(){
    var tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    var firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
}
function onYouTubeIframeAPIReady() {
    playerready = true;
}
function loadachannel(channelid){
    var url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=15&channelId='+channelid+'&type=video&fields=items%2CnextPageToken%2CpageInfo&key='+apikey;
    $('#vilist').html('');
    sendapireq(url,true,'vilist',searchres.q);    
}
function loadaplaylist(playlistid){
    searchres.q = playlistid+'#playlistitems';
            
    if(savedsearchres.length){
        for(var i=0;i<savedsearchres.length;i++){
            if(savedsearchres[i].searchres.q == searchres.q){
                savedsearchresidx = i;
                dispsearchresults('vilist');
                return;
            }
        }
    }
            
    var url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=15&playlistId='+playlistid+'&key='+apikey;
    $('#vilist').html('');
    sendapireq(url,true,'vilist',searchres.q); 
}
function loadavideo(videoid,vtitle){
    videoplayingid = videoid;
    videoplayingtitle = vtitle;
    avideoplaying = true;
    updatemenu('downloadvidensave','en.savefrom.net (s)','add');
    
    if(player !==false){
        player.loadVideoById(videoid,0,"large");
        return;
    }
    
    player = new YT.Player('player', {
        height: '390',
        width: '640',
        videoId: videoid,
        events: {
          'onReady': onPlayerReady,
          'onStateChange': onPlayerStateChange
        }
      });
}
 function onPlayerReady(event) {
    event.target.playVideo();
}
function onPlayerStateChange(event) {
    /*  BUFFERING:3,    CUED:5,    ENDED:0,    PAUSED:2,    PLAYING:1,    UNSTARTED:-1 */
    if(event.data==1){
        if($('#viwdio').attr('class').indexOf('activemin') === -1){
            updatenav('playvideo');   
        }
    }
    else if(event.data == 0){
        if(queue.length){
            cqueue++;
            cqueue = cqueue == queue.length ? 0 : cqueue;
            videoplayingid = queue[cqueue];
            videoplayingtitle = queuetitle[cqueue];
            player.loadVideoById(queue[cqueue],0,"large");
            $('#whatsinqueue').html((cqueue+1)+' of '+queue.length);
        }
    }
}
function stopVideo() {
    player.stopVideo();
}
/* end player related fn*/