const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow
const Tray = electron.Tray
const Menu = electron.Menu


let win
let apptray

const {ipcMain} = require('electron')
ipcMain.on('asynchronous-message', (event, arg) => {
  if(arg.split('<edsep>')[0] == 'canceldownload'){
    for(var i=0;i<itemtodownload.length;i++){
      if(itemtodownload[i] == arg.split('<edsep>')[1]){
        if(itemtodownloadelem[i] !== false)
          itemtodownloadelem[i].cancel()

        break
      }
    }
  }
  else if(arg.split('<edsep>')[0] == 'pausedownload'){
    for(var i=0;i<itemtodownload.length;i++){
      if(itemtodownload[i] == arg.split('<edsep>')[1]){
        if(itemtodownloadelem[i] !== false)
          itemtodownloadelem[i].pause()

        break
      }
    }
  }
  else if(arg.split('<edsep>')[0] == 'resumedownload'){
    for(var i=0;i<itemtodownload.length;i++){
      if(itemtodownload[i] == arg.split('<edsep>')[1]){
        if(itemtodownloadelem[i] !== false)
          itemtodownloadelem[i].resume()

        break
      }
    }
  }
  else if(arg.split('<edsep>')[0] == 'quitbro'){
    win.destroy();
  }
  event.sender.send('asynchronous-reply',arg)
})


itemtodownloadelem=[]
itemtodownload = []
itemtodownloadidx = 0
function draw() {
  apptray = new Tray('/media/damarsidiq/pic/icons/viwdio.png');
    const contextMenu = Menu.buildFromTemplate([
      {label: 'Item1', type: 'radio'},
      {label: 'Item2', type: 'radio'},
      {label: 'Item3', type: 'radio', checked: true},
      {label: 'Item4', type: 'radio'}
    ])
    apptray.setToolTip('Viwdio')
    apptray.setContextMenu(contextMenu)

    win = new BrowserWindow({ icon:'/media/damarsidiq/pic/icons/viwdio.png',width: 795, height: 574,frame:false,resizable: true,y:0,x:300,webPreferences: {
      webSecurity: false
    } });
    win.webContents.session.clearCache(function(){});
    win.setTitle('Viwdio');


    win.webContents.session.on('will-download', (event, item, webContents) => {
      if(typeof webContents.browserWindowOptions === 'undefined'){
        win.webContents.executeJavaScript('downloadnews("'+item.getFilename()+'<edsep>'+item.getTotalBytes()+'<edsep>startdownload<edsep>'+item.getURL()+'")',true)
      }
      else{
        win.webContents.executeJavaScript('downloadnews("'+item.getFilename()+'<edsep>'+item.getTotalBytes()+'<edsep>startdownload<edsep>popup<edsep>'+item.getURL()+'")',true)
      }


      itemtodownloadelem[itemtodownloadidx] = item
      itemtodownload[itemtodownloadidx] = item.getURL()
      itemtodownloadidx++

      item.on('updated', (event, state) => {
        if (state === 'interrupted') {
          console.log('Download is interrupted but can be resumed')
        } else if (state === 'progressing') {
          if (item.isPaused()) {
            console.log('Download is paused')
          } else {
            win.webContents.executeJavaScript('downloadnews("'+item.getFilename()+'<edsep>'+item.getReceivedBytes()+'<edsep>'+item.getURL()+'")',true)
          }
        }
      })
      item.once('done', (event, state) => {
        for(var i=0;i<itemtodownload.length;i++){
          if(itemtodownload[i] == item.getURL()){
            itemtodownloadelem[i] = false
            break
          }
        }

        if (state === 'completed') {
          win.webContents.executeJavaScript('downloadnews("'+item.getFilename()+'<edsep>downdone<edsep>'+item.getURL()+'")',true)
        } else {
          state = 'downfailed<edsep>'+state;
          win.webContents.executeJavaScript('downloadnews("'+item.getFilename()+'<edsep>'+state+'<edsep>'+item.getURL()+'")',true)
        }
      })
    });

    win.isMaximizable(true);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=viwdio&d[electronapp]=1');
    win.show();
}
app.on('ready', draw)
