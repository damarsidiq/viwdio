<?php
Class Ajax extends Controller{
    function __construct(){
        parent::__construct();
    }
    
    public function loadlist(){
        $vilist = opendir(App::getConfig('uploads'));
		$thelist = array();
		
		while( false !== ($vi = readdir($vilist))){
			if($vi == '.' || $vi == '..')
				continue;
			
            $idx = count($thelist);
			$thelist[$idx]['name'] = $vi;
            $thelist[$idx]['locat'] = App::getConfig('uploads').$vi;
		}
		
        $response['thelist'] =  $thelist;
		$this->setPagevar('response',$response);
    }
}
?>