<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data=null,$view='home'){
		return $view;
    }
}