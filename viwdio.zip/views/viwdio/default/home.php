<nav>
    <div id="menu">
        <ul id="menulist" class="">
            <li class="menuitem" id="searchyou">search (r)</li>
            <li class="menuitem" id="exit">exit</li>
        </ul>
    </div>
    <div id="logo"></div>
    
    <div id="pagenav">
        <span id="showvideo">&rtri; </span>
        <span id="removevideo">&block;</span>
        <span id="previnqueue" class="queuenav">&lt;</span>
        <span id="whatsinqueue" class="queuenav"></span>
        <span id="nextinqueue" class="queuenav">&gt;</span>
        <span id="navtonext">&gt;</span>
        <span id="pagecount">1</span>
        <span id="navtoprev">&lt;</span>
        <span id="relatedvideo">&capbrcup;</span>
    </div>
</nav>
<div id="vilist" class="maincontent active"></div>
<div id="viwdio" class="maincontent">
    <a href="" id="player"></a>
</div>
<div id="relviwdio" class="maincontent">
    
</div>
<div id="downloadpage" class="maincontent"></div>
<div id="playlistpage" class="maincontent"></div>
<div id="opaque" class="maincontent"></div>
<div id="searchform" class="maincontent">
    <div class="table">
        <div class="tablecell">
            <div id="searchedkeys" class="maincontent"></div>
            <input type="text" value="keyword" name="keyword" id="searchq">
        </div>
    </div>
</div>